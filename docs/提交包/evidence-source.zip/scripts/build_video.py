"""演示视频合成：把界面截图与配音合成为 1080p MP4。

设计前提：
- 讲解音频由作者本人录制（赛题要求普通话讲解），本脚本只做合成；
- 画面由 scripts/ui_shot.py 抓取的截图构成，按镜头脚本排序；
- 不依赖剪映/Premiere，一条命令产出可提交的 mp4。

用法：
  # 1) 先看有哪些镜头（不改文件）
  .venv\\Scripts\\python.exe scripts/build_video.py --audio 讲解.m4a --dry-run

  # 2) 正式合成
  .venv\\Scripts\\python.exe scripts/build_video.py --audio 讲解.m4a --out docs/演示视频.mp4

  # 3) 没有音频时先验证管线（生成静音占位，仅供自测）
  .venv\\Scripts\\python.exe scripts/build_video.py --silent 8:00 --out docs/pipeline-test.mp4

时间分配：默认按脚本里的权重把音频总时长分给各镜头；
也可以用 --timing 指定每个镜头的秒数。
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHOT_DIR = ROOT / "docs" / "video-shots"
FIGS = ROOT / "docs" / "figures-ui"

# 画面 1920x1080 拆成两部分：界面区 1920x972 + 字幕带 108px
FRAME_W, FRAME_H = 1920, 1080
BAR_H = 108
CONTENT_H = FRAME_H - BAR_H

# 镜头顺序与权重，对应 docs/演示视频脚本.md 的分镜。
# 与文档共用的界面图直接引用 figures-ui，避免仓库里存两份。
SHOTS: list[dict] = [
    {"name": "00-cover", "file": SHOT_DIR / "00-cover.png",
     "caption": "证源 Evidence —— 带段落级锚点溯源的科研助手 Agent"},
    {"name": "01-reader", "file": FIGS / "02-reader.png",
     "caption": "① 解析：从字符坐标重建标题树，保留原版式"},
    {"name": "02-ask", "file": FIGS / "01-ask.png",
     "caption": "② 有据问答：[E1] 标记经服务端校验，可跳回原文某行"},
    {"name": "03-refusal", "file": SHOT_DIR / "03-refusal.png",
     "caption": "③ 抗幻觉：答不出就拒答，并说明为什么"},
    {"name": "04-bilingual", "file": SHOT_DIR / "04-bilingual.png",
     "caption": "④ 双语联动：按段落锚点对齐，拖动任一侧另一侧跟随"},
    {"name": "05-graph", "file": FIGS / "03-graph.png",
     "caption": "⑤ 引用图谱：22 篇 → 21 节点 56 边，基石论文金色描边"},
    {"name": "06-discover", "file": FIGS / "05-discover.png",
     "caption": "⑥ 论文发现：60% 语义相近 + 25% 可复现性 + 15% 方向偏好"},
    {"name": "07-charts", "file": SHOT_DIR / "07-charts.png",
     "caption": "⑦ 数据可视化：量级差自动分副轴，附可复现脚本"},
    {"name": "08-compare", "file": FIGS / "04-compare.png",
     "caption": "⑧ 技术亮点：三道抗幻觉约束、字符级解析、可执行断言"},
    {"name": "09-closing", "file": SHOT_DIR / "09-closing.png",
     "caption": "让每一个结论，都能回到原文"},
]


def find_ffmpeg() -> str:
    """优先用工作区里的便携版，其次 PATH。"""
    for candidate in (
        ROOT / ".cache" / "ffmpeg" / "ffmpeg.exe",
        *ROOT.glob(".cache/ffmpeg/**/bin/ffmpeg.exe"),
        *ROOT.glob(".cache/ffmpeg/**/ffmpeg.exe"),
    ):
        if Path(candidate).exists():
            return str(candidate)
    from shutil import which

    found = which("ffmpeg")
    if found:
        return found
    raise SystemExit(
        "找不到 ffmpeg。放到 .cache/ffmpeg/ 下，或装到 PATH 里。\n"
        "下载地址：https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
    )


def find_font(size: int):
    """给字幕条找中文字体；找不到就退回默认字体（可能缺字，但不会崩）。"""
    from PIL import ImageFont

    for path in (
        r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\msyhbd.ttc",
        r"C:\Windows\Fonts\simhei.ttf",
    ):
        if Path(path).exists():
            try:
                return ImageFont.truetype(path, size)
            except Exception:  # noqa: BLE001
                continue
    return ImageFont.load_default()


def make_caption_png(text: str, out: Path, width: int = 1920, height: int = 1080) -> Path:
    """画整帧大小的字幕层：上方透明、底部 BAR_H 像素是字幕带。

    为什么不在 ffmpeg 里用 drawtext/subtitles：中文文本要经过多层转义，
    正则在 Windows 路径上还容易踩坑；先用 PIL 画成图片再 overlay，
    可控且不会有编码问题。

    字幕带是**独立区域**：画面缩到 1920x972 顶置，底部 108px 只放字幕。
    盖住界面会让"看得见的功能"变成"看不清的功能"。
    """
    from PIL import Image, ImageDraw

    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    top = height - BAR_H
    d.rectangle([0, top, width, height], fill=(10, 13, 19, 255))
    d.rectangle([0, top, width, top + 2], fill=(96, 165, 250, 255))

    font = find_font(38)
    bbox = d.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    d.text(((width - tw) / 2, top + (BAR_H - th) / 2 - bbox[1]), text,
           font=font, fill=(235, 240, 248, 255))
    img.save(out)
    return out


def probe_duration(ffmpeg_exe: str, audio: Path) -> float:
    """用 ffmpeg 自带的 ffprobe 取时长。"""
    ffprobe = Path(ffmpeg_exe).with_name("ffprobe.exe")
    if not ffprobe.exists():
        from shutil import which

        found = which("ffprobe")
        if not found:
            raise SystemExit("找不到 ffprobe")
        ffprobe = Path(found)
    out = subprocess.run(
        [str(ffprobe), "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(audio)],
        capture_output=True, text=True, check=True,
    )
    return float(out.stdout.strip())


def plan(timing: list[float] | None, total: float) -> list[float]:
    if timing:
        if len(timing) != len(SHOTS):
            raise SystemExit(f"--timing 需要 {len(SHOTS)} 个秒数")
        return timing
    weight_sum = sum(s.get("weight", 1.0) for s in SHOTS) or 1.0
    return [round(total * s.get("weight", 1.0) / weight_sum, 2) for s in SHOTS]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--audio", help="讲解音频（m4a/mp3/wav）")
    ap.add_argument("--silent", help="无音频自测：给定时长 MM:SS，生成静音占位")
    ap.add_argument("--out", default="docs/演示视频.mp4")
    ap.add_argument("--timing", help="逗号分隔的每镜头秒数")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--no-captions", action="store_true", help="不叠加镜头字幕条")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    missing = [s["name"] for s in SHOTS if not Path(s["file"]).exists()]
    if missing:
        print(f"[错误] 缺少截图：{missing}\n先把画面抓齐：scripts/ui_shot.py 或从 docs/preview 复制到 docs/figures-ui")
        return 1

    if args.audio:
        audio = Path(args.audio)
        if not audio.exists():
            raise SystemExit(f"音频不存在：{audio}")
        ffmpeg_exe = find_ffmpeg()
        total = probe_duration(ffmpeg_exe, audio)
        print(f"音频：{audio.name}  时长 {total:.1f}s")
    elif args.silent:
        mm, ss = args.silent.split(":")
        total = int(mm) * 60 + int(ss)
        ffmpeg_exe = find_ffmpeg()
        audio = None
        print(f"静音占位：{total}s（仅用于验证管线）")
    else:
        raise SystemExit("要么给 --audio，要么给 --silent MM:SS")

    timing = [float(x) for x in args.timing.split(",")] if args.timing else None
    durations = plan(timing, total)
    print(f"\n镜头 {len(SHOTS)} 个，合计 {sum(durations):.1f}s")
    for shot, dur in zip(SHOTS, durations):
        print(f"  {dur:6.1f}s  {shot['name']:<12} {shot['caption']}")

    if args.dry_run:
        print("\n（dry-run，未生成文件）")
        return 0

    # 每张图先做成固定时长的片段，再拼接；最后混入音频
    from tempfile import TemporaryDirectory

    out_path = (ROOT / args.out) if not Path(args.out).is_absolute() else Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)
        segs: list[Path] = []
        for i, (shot, dur) in enumerate(zip(SHOTS, durations)):
            seg = tmp_dir / f"seg{i:02d}.mp4"
            target_h = CONTENT_H if not args.no_captions else FRAME_H
            # 等比缩放 + 顶置补边：pad 的 x/y 显式给 0，
            # 否则 pad 会居中，导致画面上下都有空带、字幕带位置对不上
            if args.no_captions:
                vf = (
                    f"scale={FRAME_W}:{FRAME_H}:force_original_aspect_ratio=decrease,"
                    f"pad={FRAME_W}:{FRAME_H}:(ow-iw)/2:(oh-ih)/2:color=0x0a0d13"
                )
            else:
                vf = (
                    f"scale={FRAME_W}:{target_h}:force_original_aspect_ratio=decrease,"
                    f"pad={FRAME_W}:{FRAME_H}:0:0:color=0x0a0d13"
                )
            inputs = [ffmpeg_exe, "-y", "-loop", "1", "-i", str(shot["file"])]
            extra: list[str] = []

            if not args.no_captions:
                cap_png = make_caption_png(
                    shot["caption"], tmp_dir / f"cap{i:02d}.png", FRAME_W, FRAME_H
                )
                inputs += ["-loop", "1", "-i", str(cap_png)]
                # 两个输入要用 filter_complex，不能用 -vf
                # （-vf 只接受单输入，会报 "expected to have exactly 1 input"）
                fg = f"[0:v]{vf}[bg];[bg][1:v]overlay=0:0:format=auto[v]"
                extra = ["-filter_complex", fg, "-map", "[v]"]
            else:
                extra = ["-vf", vf]

            cmd = inputs + [
                "-t", f"{dur:.2f}", *extra, "-r", str(args.fps),
                "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium",
                str(seg),
            ]
            r = subprocess.run(cmd, capture_output=True)
            if r.returncode != 0:
                raise SystemExit(
                    f"生成第 {i + 1} 个镜头失败：\n{r.stderr.decode('utf-8', 'ignore')[-600:]}"
                )
            segs.append(seg)

        concat_list = tmp_dir / "list.txt"
        concat_list.write_text(
            "\n".join(f"file '{s.as_posix()}'" for s in segs), encoding="utf-8"
        )
        merged = tmp_dir / "merged.mp4"
        subprocess.run(
            [ffmpeg_exe, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_list),
             "-c", "copy", str(merged)],
            capture_output=True, check=True,
        )

        if audio is None:
            # 静音占位
            subprocess.run(
                [ffmpeg_exe, "-y", "-i", str(merged), "-f", "lavfi", "-i",
                 "anullsrc=channel_layout=stereo:sample_rate=44100",
                 "-shortest", "-c:v", "copy", "-c:a", "aac", "-b:a", "128k",
                 str(out_path)],
                capture_output=True, check=True,
            )
        else:
            subprocess.run(
                [ffmpeg_exe, "-y", "-i", str(merged), "-i", str(audio),
                 "-c:v", "copy", "-c:a", "aac", "-b:a", "160k",
                 "-shortest", "-movflags", "+faststart", str(out_path)],
                capture_output=True, check=True,
            )

    size_mb = out_path.stat().st_size / 1e6
    print(f"\n已生成 {out_path}  {size_mb:.1f}MB")
    print(f"分辨率 {FRAME_W}x{FRAME_H} @{args.fps}fps，时长约 {sum(durations):.0f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
